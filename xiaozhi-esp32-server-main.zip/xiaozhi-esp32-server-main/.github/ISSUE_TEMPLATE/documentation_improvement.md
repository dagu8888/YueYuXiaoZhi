---
name: 文档改进建议（Documentation Improvement）
about: 提出对项目文档的改进或补充建议
title: "[Docs] 简短描述改进内容"
labels: documentation
assignees: ''
---

## 📚 改进描述
<!-- 描述需要改进的文档部分以及存在的问题 -->

## ✨ 改进建议
<!-- 提出具体的改进方案或内容 -->

## 📋 其他信息
<!-- 在此添加任何其他相关信息 -->
