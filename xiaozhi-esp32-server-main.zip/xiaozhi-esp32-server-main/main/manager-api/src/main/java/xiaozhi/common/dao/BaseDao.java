package xiaozhi.common.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 基础Dao
 * Copyright (c) 人人开源 All rights reserved.
 * Website: https://www.renren.io
 */
public interface BaseDao<T> extends BaseMapper<T> {

}
