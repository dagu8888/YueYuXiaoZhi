package xiaozhi.common.validator.group;

/**
 * 修改 Group
 */
public interface UpdateGroup {

}
