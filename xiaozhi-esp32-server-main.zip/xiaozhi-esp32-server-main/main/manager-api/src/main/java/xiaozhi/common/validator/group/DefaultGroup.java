package xiaozhi.common.validator.group;

/**
 * 默认 Group
 */
public interface DefaultGroup {

}
